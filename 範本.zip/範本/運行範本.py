from keys import api,secret
from binance.um_futures import UMFutures
import ta #technical analysis library in python
import pandas as pd
from time import sleep
from binance.error import ClientError

import ccxt
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone


def get_binance_usdt():
    try:
        response = client.account()  # 使用 Futures 合約中的 account 方法
        for asset in response['assets']:
            if asset['asset'] == 'USDT':
                usdt_balance = float(asset['walletBalance'])
                return usdt_balance

    except ClientError as error:
        print(
            "Found error. status: {}, error code: {}, error message: {}".format(
                error.status_code, error.error_code, error.error_message
            )
        )



def get_tickers_usdt():
    tickers = []
    resp = client.ticker_price()
    current_time = datetime.now(timezone.utc)  # 獲取當前 UTC 時間

    for elem in resp:
        # 檢查是否為包含 'USDT' 的交易對，並排除 'USDCUSDT' 和帶有下劃線的交易對
        if 'USDT' in elem['symbol'] and elem['symbol'] != 'USDCUSDT' and '_' not in elem['symbol']:
            # 獲取交易對的上市時間
            listing_info = client.exchange_info()
            for symbol_info in listing_info['symbols']:
                if symbol_info['symbol'] == elem['symbol']:
                    # 將上市時間轉換為日期
                    listing_time = datetime.fromtimestamp(symbol_info['onboardDate'] / 1000, tz=timezone.utc)
                    # 計算上市時間與當前時間的差距
                    if (current_time - listing_time).days >= 30:
                        tickers.append(elem['symbol'])
                    break

    return tickers



def fetch_historical_data(symbol, timeframe, since, limit):
    try:
        all_data = []
        while True:
            ohlcv = ccxtexchange.fetch_ohlcv(symbol, timeframe, since=since, limit=limit)
            if len(ohlcv) == 0:
                break
            all_data.extend(ohlcv)
            # 更新 since 為當前獲取的最後一根K線的時間戳 + 1毫秒，避免重複
            since = ohlcv[-1][0] + 1
            if len(ohlcv) < limit:
                break
        df = pd.DataFrame(all_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)  # 設置時間索引
        return df 
    except ccxt.BaseError as error:
        print(
            "Found error. status:{},error code:{}, error massage:{}".format(
                error.status_code,error.error_code,error.error_message
            )
        )
# def fetch_long_short_ratio(symbol, interval, limit): 策略放這 這是範例你要自己做
#     return ratio_df

def set_leverage(symbol,level):
    try:
        response = client.change_leverage(
            symbol=symbol, leverage=level, recvWindow=6000
        )
        print(response)
    except ClientError as error:
        print(
            "Found error. status: {}, error code: {}, error message: {}".format(
                error.status_code, error.error_code, error.error_message
            )
        )
def set_mode(symbol,margin_type):
    try:
        response = client.change_margin_type(
            symbol=symbol, marginType=margin_type, recvWindow=6000
        )
        print(response)
    except ClientError as error:
        print(
            "Found error. status: {}, error code: {}, error message: {}".format(
                error.status_code, error.error_code, error.error_message
            )
    )

def get_price_precision(symbol):#Quote Asset 單位精度
    resp = client.exchange_info()
    
    if 'symbols' in resp:
        for elem in resp['symbols']:
            if isinstance(elem, dict) and 'symbol' in elem:
                if elem['symbol'] == symbol:
                    return elem['pricePrecision']
    return None

        
def get_qty_precision(symbol):#Base Asset 單位精度
    resp = client.exchange_info()
    
    if 'symbols' in resp:
        for elem in resp['symbols']:
            if isinstance(elem, dict) and 'symbol' in elem:
                if elem['symbol'] == symbol:
                    return elem['quantityPrecision']
    return None

        
def open_order(symbol,side,volume):
    order_book = ccxtexchange.fetch_order_book(symbol)
    price = float(client.ticker_price(symbol)['price'])
    qty_precison = get_qty_precision(symbol)
    price_precision = get_price_precision(symbol)
    # volume=get_binance_usdt()*(leverage/1.392946867) #volume是買入usdt倉位大小(保證金*槓桿)
    qty =  round(volume/price,qty_precison) #volume是買入usdt倉位大小(保證金*槓桿)
        # 目標成交數量
    target_usdt = volume  # 目標 USDT 數量

    accumulated_qty = 0  # 累積數量
    accumulated_cost = 0  # 累積價格成本

    # 根據方向檢查對手價委託量
    if side == 'buy':  # 做多
        for price_level, qty_level in order_book['bids']:
            accumulated_qty += qty_level
            accumulated_cost += price_level * qty_level
            if accumulated_cost >= target_usdt:
                break
    elif side == 'sell':  # 做空
        for price_level, qty_level in order_book['asks']:
            accumulated_qty += qty_level
            accumulated_cost += price_level * qty_level
            if accumulated_cost >= target_usdt:
                break

    # 如果累積的數量小於所需，則跳過該symbol
    if accumulated_cost < target_usdt:
        print(f"Insufficient liquidity for {symbol}. Skipping...")
        return False

    # 計算平均成交價格
    avg_price = accumulated_cost / accumulated_qty

    # 計算價格差異，若差異超過 0.3%，則跳過該symbol
    if side == 'buy':
        price_difference = (avg_price - price) / price
    if side == 'sell':
        price_difference = (price - avg_price) / price
    if price_difference > 0.003:
        print(f"Average price for {symbol} deviates more than 0.3%. Skipping...")
        return False
    
    if side == 'buy':
        try:
            resp1 = client.new_order(symbol=symbol,side='BUY',type='MARKET',quantity=qty)#,timeInForce='GTC',price=price)
            print(symbol,side,"placing order....")
            print(resp1)
            sleep(2)
            
            sl_price = round(price-price*sl,price_precision)
            resp2 = client.new_order(
                symbol=symbol,
                side='SELL',
                type='STOP_MARKET',
                quantity=qty,
                # timeInForce='GTC',
                stopPrice=sl_price)
            print(resp2)
            sleep(2)
            tp_price = round(price+price*tp,price_precision)
            resp3 = client.new_order(
                symbol=symbol,
                side='SELL',
                type='TAKE_PROFIT_MARKET',
                quantity=qty,
                # timeInForce='GTC',
                stopPrice=tp_price)
            print(resp3)
            return True
        except ClientError as error:
            print(
                "Found error. status: {}, error code: {}, error message: {}".format(
                    error.status_code, error.error_code, error.error_message
                )
            )
            return False
    if side == 'sell':
        try:
            resp1 = client.new_order(symbol=symbol,side='SELL',type='MARKET',quantity=qty)#,timeInForce='GTC',price=price)
            print(symbol,side,"placing order....")
            print(resp1)
            sleep(2)
            
            sl_price = round(price+price*sl,price_precision)
            resp2 = client.new_order(
                symbol=symbol,
                side='BUY',
                type='STOP_MARKET',
                quantity=qty,
                # timeInForce='GTC',
                stopPrice=sl_price)
            print(resp2)
            sleep(2)
            tp_price = round(price-price*tp,price_precision)
            resp3 = client.new_order(
                symbol=symbol,
                side='BUY',
                type='TAKE_PROFIT_MARKET',
                quantity=qty,
                # timeInForce='GTC',
                stopPrice=tp_price)
            print(resp3)
            return True
        except ClientError as error:
            print(
                "Found error. status: {}, error code: {}, error message: {}".format(
                    error.status_code, error.error_code, error.error_message
                )
            )
            return False
def check_position():
    try:
        resp = client.get_position_risk()
        position=0
        for elem in resp:
            if float(elem['positionAmt'])!=0:
                position +=1
        return position
    except ClientError as error:
        print(
            "Found error. status: {}, error code: {}, error message: {}".format(
                error.status_code, error.error_code, error.error_message
            )
        )
def close_open_order(symbol):
    try:
        response = client.cancel_open_orders(symbol=symbol, recvWindow=2000)
        print(response)
        return True
    except ClientError as error:
        print(
            "Found error. status: {}, error code: {}, error message: {}".format(
                error.status_code, error.error_code, error.error_message
            )
        )
        return False
    
def close_open_position(symbol):
    """
    使用 Binance API 平倉操作 (閉合所有倉位)
    """
    try:
        response = client.futures_close_position(symbol=symbol, recvWindow=6000)
        print(f"Position closed for {symbol}: {response}")
        return True
    except ClientError as error:
        print(
            "Error closing position. status: {}, error code: {}, error message: {}".format(
                error.status_code, error.error_code, error.error_message
            )
        )
        return False



def calculate_strategy(df):
    long_position = False
    short_position = False

    if not short_position and not long_position:

        # 新增條件：做多
        if df['xxxx'].iloc[-1]<x: #'策略' [數據位置 -1代表最近一根k棒 ] > < = !=是判斷
            return "long"

        # 新增條件：做空
        elif df['xxx'].iloc[-1]>x : #'策略' [數據位置 -1代表最近一根k棒 ] > < = !=是判斷
            return "short"
        
        else:
            return "none"



client = UMFutures(key =api,secret=secret)
ccxtexchange = ccxt.binance()

tp=0.1
sl=0.1
leverage=1
margin_type="CROSSED" #CROSSED or ISOLATED

order=False
symbol=""
symbols= get_tickers_usdt()
# #symbols=["BTCUSDT","ETHUSDT"]

timeframe='1h'#頻率 可改
current_position = None

    # 計算下一個 14, 29, 44, 59 分鐘的時間點
def get_next_check_time(now):
    hour=0
    current_minute = now.minute
    if current_minute < 57:
        next_check_minute = 56
    else:
        next_check_minute = 56
        hour=1
    if hour==0:
        next_check = now.replace(second=0, microsecond=0, minute=next_check_minute)
    elif hour==1:
        next_check = now.replace(second=0, microsecond=0, minute=next_check_minute)+ timedelta(hours=1)
        
    return next_check


is_first_iteration = True
max_value=0000#改成自己的倉位大小
# 檢查交易機會
while True:
    # if is_first_iteration: #如果目前有倉位 程式碼重開 需要打先前持倉內容
    #     # 第一次運行的邏輯，使用變數
    #     print("第一次運行，使用變數!")
    #     symbol = "APEUSDT"  # 例如：現在庫存
    #     order= True
    #     current_position = 'long'
    #     is_first_iteration = False  # 更新標誌變數
    #     max_value=xxxx#改成自己的倉位大小
    now = datetime.now(timezone.utc)
    since = int((now - timedelta(days=11)).timestamp() * 1000) #202
    next_check = get_next_check_time(now)
    sleep_time = (next_check - now).total_seconds()

    if sleep_time > 0:
        print(f"等待 {sleep_time} 秒，直到 {next_check.strftime('%Y-%m-%d %H:%M:%S')}")
        sleep(sleep_time)


    while True:
        now = datetime.now(timezone.utc)
        # if now.minute in [0, 15, 30, 45] and now.second == 0:
        if now.minute in [57] and now.second == 0:
            print(f"到達檢查時間點: {now.strftime('%Y-%m-%d %H:%M:%S')}，開始檢查交易機會")
            
            positions = check_position()
            print(f"You have {positions} opened positions")
            
            ##############################################################

            ###############################################################
            myusdt = get_binance_usdt()
            if myusdt >= max_value :
                volume = myusdt
                max_value = myusdt
                leverage = 2
                print("預設倉位:",volume)
            else:
                volume = max_value
                leverage = 2
                print("預設倉位:",volume)
            ################################################################
            if positions==0:
                order= False
                current_position = None
                if symbol !="":
                    close_open_order(symbol)
                    symbol = ""
            if positions!=0:
                order= True
            if order == False:
                for elem in symbols: 
                    df = fetch_historical_data(elem, timeframe, since, limit=1000)
                    #df=策略 必填#####################
                    signal = calculate_strategy(df)
                    if signal == 'long':
                        print('Found BUY Signal for',elem)
                        set_mode(elem,margin_type)
                        sleep(1)
                        set_leverage(elem,leverage)
                        sleep(1)
                        print("Placing Order for",elem)
                        if open_order(elem, "buy",volume=volume):
                            current_position = 'long' 
                            symbol = elem
                            order = True
                            break
                        else:
                            print("Long order placement failed, retrying...")
                        
                    if signal == 'short':
                        print('Found Sell Signal for',elem)
                        set_mode(elem,margin_type)
                        sleep(1)
                        set_leverage(elem,leverage)
                        sleep(1)
                        print("Placing Order for",elem)
                        if open_order(elem, "sell",volume=volume):
                            current_position = 'short' 
                            symbol = elem
                            order = True
                            break
                        else:
                            print("Short order placement failed, retrying...") 


            break
    sleep(1)