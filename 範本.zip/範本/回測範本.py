from keys import api,secret
from binance.um_futures import UMFutures
import ta #technical analysis library in python
import pandas as pd
from time import sleep
from binance.error import ClientError
import ccxt
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone

# 定義手續費率
fee_rate = 0.001  # 0.1% 交易手續費
# 初始化Binance交易所
client = UMFutures(key =api,secret=secret)
ccxtexchange = ccxt.binance()
exchange = ccxt.binance()
# 獲取歷史數據函數（分批請求）
def fetch_historical_data(symbol, timeframe, since, limit):
    all_data = []
    while True:
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe, since=since, limit=limit)
        if len(ohlcv) == 0:
            break
        all_data.extend(ohlcv)
        # 更新 since 為當前獲取的最後一根K線的時間戳 + 1毫秒，避免重複
        since = ohlcv[-1][0] + 1
        if len(ohlcv) < limit:
            break
    df = pd.DataFrame(all_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)  # 設置時間索引
    return df


def vol(df):
    # 計算成交量的3MA和10MA
    df['volume_10ma'] = df['volume'].rolling(window=10).mean()
    # 每根K線的成交量是否大於其對應的3MA和10MA
    df['is_current_volume_above_10ma'] = df['volume'] > df['volume_10ma']
    return df

# 計算策略函數
def calculate_strategy(df, stop_loss_percentage, take_profit_percentage):
    
    df['strategy_return'] = 0.0
    long_position = False
    short_position = False
    entry_price = 0
    profit_trades = 0
    total_trades = 0
    total_return = 0.0
    profit_return_sum = 0.0
    trades = []

    for i in range(1, len(df) - 1):

        # 創建一個布林值，表示是否符合所有條件
        if not short_position and not long_position:


            # 新增條件：做多
            if  df['xxxxxxx'].iloc[i-1]<x:#策略
                long_position = True

                entry_price = df['close'].iloc[i]
                trades.append({
                    'timestamp': df.index[i],
                    'action': 'Long',
                    'entry_price': entry_price,
                })
                continue

            # 新增條件：做空
            elif df['xxxxxxx'].iloc[i]>x :#策略
                short_position = True

                entry_price = df['close'].iloc[i]
                trades.append({
                    'timestamp': df.index[i],
                    'action': 'Short',
                    'entry_price': entry_price,
                })
                continue

        # Long exit condition
        if long_position:
            stop_loss_price = entry_price * (1 - stop_loss_percentage)
            take_profit_price = entry_price * (1 + take_profit_percentage)
            if df['low'].iloc[i] <= stop_loss_price:
                exit_price = stop_loss_price
                exit_price_after_fee = exit_price * (1 - fee_rate)
                entry_price_after_fee = entry_price * (1 + fee_rate)
                trade_return = ((exit_price_after_fee - entry_price_after_fee) / entry_price_after_fee)
                df['strategy_return'].iloc[i] = trade_return
                total_return += trade_return
                long_position = False
                total_trades += 1
                if trade_return > 0:
                    profit_trades += 1
                    profit_return_sum += trade_return
                trades.append({
                    'timestamp': df.index[i],
                    'action': 'Long Exit',
                    'entry_price': entry_price_after_fee,
                    'exit_price': exit_price_after_fee,
                    'profit_percentage': trade_return * 100
                })

            elif df['high'].iloc[i] >= take_profit_price:
                exit_price = take_profit_price
                exit_price_after_fee = exit_price * (1 - fee_rate)
                entry_price_after_fee = entry_price * (1 + fee_rate)
                trade_return = ((exit_price_after_fee - entry_price_after_fee) / entry_price_after_fee)
                df['strategy_return'].iloc[i] = trade_return
                total_return += trade_return
                long_position = False
                total_trades += 1
                if trade_return > 0:
                    profit_trades += 1
                    profit_return_sum += trade_return
                trades.append({
                    'timestamp': df.index[i],
                    'action': 'Long Exit',
                    'entry_price': entry_price_after_fee,
                    'exit_price': exit_price_after_fee,
                    'profit_percentage': trade_return * 100
                })

        # Short exit condition
        elif short_position:
            stop_loss_price = entry_price * (1 + stop_loss_percentage)
            take_profit_price = entry_price * (1 - take_profit_percentage)
            if df['high'].iloc[i] >= stop_loss_price:
                exit_price = stop_loss_price
                exit_price_after_fee = exit_price * (1 + fee_rate)
                entry_price_after_fee = entry_price * (1 - fee_rate)
                trade_return = ((entry_price_after_fee - exit_price_after_fee) / entry_price_after_fee)
                df['strategy_return'].iloc[i] = trade_return
                total_return += trade_return
                short_position = False
                total_trades += 1
                if trade_return > 0:
                    profit_trades += 1
                    profit_return_sum += trade_return
                trades.append({
                    'timestamp': df.index[i],
                    'action': 'Short Exit',
                    'entry_price': entry_price_after_fee,
                    'exit_price': exit_price_after_fee,
                    'profit_percentage': trade_return * 100
                })

            elif df['low'].iloc[i] <= take_profit_price:
                exit_price = take_profit_price
                exit_price_after_fee = exit_price * (1 + fee_rate)
                entry_price_after_fee = entry_price * (1 - fee_rate)
                trade_return = ((entry_price_after_fee - exit_price_after_fee) / entry_price_after_fee)
                df['strategy_return'].iloc[i] = trade_return
                total_return += trade_return
                short_position = False
                total_trades += 1
                if trade_return > 0:
                    profit_trades += 1
                    profit_return_sum += trade_return
                trades.append({
                    'timestamp': df.index[i],
                    'action': 'Short Exit',
                    'entry_price': entry_price_after_fee,
                    'exit_price': exit_price_after_fee,
                    'profit_percentage': trade_return * 100
                })

    win_rate = (profit_trades / total_trades) * 100 if total_trades > 0 else 0
    avg_profit_per_trade = (total_return / total_trades) * 100 if total_trades > 0 else 0
    avg_profit_when_profitable = (profit_return_sum / profit_trades) * 100 if profit_trades > 0 else 0

    return win_rate, avg_profit_per_trade, total_trades, profit_trades, avg_profit_when_profitable, trades



# 設置回測參數
timeframe = '1h' #頻率
now = datetime.now(timezone.utc)
since = int((now - timedelta(days=43)).timestamp() * 1000) #回測天數

stop_loss_percentage = 0.1
take_profit_percentage = 0.1 #停損利
# 參數 ....Sma,,,,,,

def get_all_usdt_perpetual_pairs():
    markets = exchange.load_markets()
    
    # 用于存储符合条件的永续合约
    usdt_perpetual_pairs = []
    
    # 遍历市场，检查每个交易对的type和symbol
    for symbol, info in markets.items():
        # 检查 'type' 是否为 'swap'（永续合约）并且 symbol 中包含 'USDT'
        if info['type'] == 'swap' and 'USDT' in symbol:
            usdt_perpetual_pairs.append(symbol)
    
    return usdt_perpetual_pairs

symbols = get_all_usdt_perpetual_pairs()
# symbols=["ETHUSDT","BTCUSDT"]
all_trades = []
summary_results = []

for symbol in symbols:
    try:
        # 獲取歷史數據
        df = fetch_historical_data(symbol, timeframe, since, limit=1000)
        
        # 策略 一定要加
        # df = vol(df)
        #
        #
        #.....
        win_rate, avg_profit, total_trades, profit_trades, avg_profit_profitable, trades = calculate_strategy(df, stop_loss_percentage, take_profit_percentage, diff_num, small_day, big_day)
        
        # 保存交易紀錄
        for trade in trades:
            trade['symbol'] = symbol
            all_trades.append(trade)
        
        # 保存回測總結
        summary_results.append({
            'symbol': symbol,
            'win_rate': win_rate,
            'avg_profit_per_trade': avg_profit,
            'total_trades': total_trades,
            'profit_trades': profit_trades,
            'avg_profit_when_profitable': avg_profit_profitable
        })

    except Exception as e:
        print(f"處理 {symbol} 發生錯誤: {e}")

trades_df = pd.DataFrame(all_trades)
summary_df = pd.DataFrame(summary_results)

trades_df.to_csv(f'xxx_trades_return_xxx{int(take_profit_percentage*100)}_{int(stop_loss_percentage*100)}.csv', index=False)
summary_df.to_csv(f'xxx_xxx{int(take_profit_percentage*100)}_{int(stop_loss_percentage*100)}.csv', index=False)

print("所有交易紀錄已保存至 USDT_trades_summary.csv")
print("策略總結已保存至 USDT_backtest_summary.csv")
